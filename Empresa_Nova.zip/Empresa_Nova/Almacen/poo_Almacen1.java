package Almacen;

public class poo_Almacen1 {
    String num_producto;
    String nombre;
    String precio;
    public poo_Almacen1(){
        
    }
    //constructor
    public poo_Almacen1(String num_producto, String nombre, String precio ){
        this.num_producto=num_producto;
        this.nombre=nombre;
        this.precio=precio;
    }
    public String get_num_producto(){
        return num_producto;
    }
    public void set_num_producto(String num_producto){
        this.num_producto=num_producto;
    }
    public String get_nombre(){
        return nombre;
    }
    public void set_nombre(String nombre){
        this.nombre=nombre;
    }
    public String get_precio(){
        return precio;
    }
    public void set_precio(String precio){
        this.precio=precio;
    }

    
}
