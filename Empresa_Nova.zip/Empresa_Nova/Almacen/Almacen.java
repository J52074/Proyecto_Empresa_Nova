package Almacen;
import java.util.Scanner;
import java.sql.CallableStatement;//Esta biblioteca para trabajar con procedimientos almacenados de la base de datos
import java.sql.Connection;
import java.sql.SQLException;//para manejo de errores de sql
public class Almacen {
    public static void main(String[]args){
        Scanner scr = new Scanner(System.in);
        int opcion;
        do{
            System.out.println("--------------------------------------------------------- ");
            System.out.println("1. Almacen 1 ");
            System.out.println("2. Almacen 2 ");
            System.out.println("3. Almacen 3 ");
            System.out.println("4. Almacen 4 ");
            System.out.println("5. Almacen 5 ");
            System.out.println("6. Salida");
            System.out.println("--------------------------------------------------------- ");
            System.out.println("Ingrese una opcion ");
            opcion=scr.nextInt();
            switch (opcion) {
                case 1:
                    do{
                        System.out.println("--------------------------------------------------------- ");
                        System.out.println(" Ingreso y Modifacion de productos ");
                        System.out.println("1. Registar un producto ");
                        System.out.println("2. Modificar un producto ");
                        System.out.println("3. Salida");
                        System.out.println("--------------------------------------------------------- ");
                        System.out.println("Ingrese una opcion ");
                        opcion=scr.nextInt();
                        scr.nextLine();
                        switch (opcion) {
                            case 1:
//matches sigifica que verifica que el nombre ese dentro del rango dicho con
//  minisculas y mayusculasde desde a la a hasta la z y mas es para que acepte masque un caracter 
//.isEmpty es para saber si nombre esta vacio o no es decir si el usuario ingreso datos o no 
//.trim() elimina espacios
                                    System.out.println("Ingrese el codigo del producto: ");
                                    String codigo =scr.nextLine();
                                    //verificacion del codigo del producto
                                    while (codigo.isEmpty())
                                    {
                                        System.out.println("Dato Invalido");
                                        System.out.println("Ell codigo no puede estar en blanco");
                                        System.out.println("Ingrese el codigo del producto nuevamente:");
                                        codigo =scr.nextLine();
                                    }
                                    while (!codigo.matches("[0-9]{10}"))
                                    {
                                        System.out.println("Dato Invalido");
                                        System.out.println("El codigo solo puede tener numeros positivos, sin espacios  y con un maximo de 10 digitos");
                                        System.out.println("Ingrese el codigo del producto nuevamente:");
                                        codigo =scr.nextLine();
                                    }
                                    String Resultado = ProductoDublicado(codigo);
                                    if (Resultado.equals("DUPLICADO"))
                                    {
                                        System.out.println("DUPLICADO");
                                        break;
                                        
                                    }
                                    //***************************************************************************************************** 
                                    System.out.println("Ingrese el nombre del producto: ");
                                    String nombre=scr.nextLine();
                                    //verificacion del nombre 
                                    while (nombre.trim().isEmpty())
                                    { 
                                        System.out.println("Dato Invalido");
                                        System.out.println("El nombre no puede estar en blanco o lleno de espacios");
                                        System.out.println("Ingrese el nombre del producto nuevamente:");
                                        nombre=scr.nextLine();
                                    } 
                                    while (!nombre.matches("[a-zA-Z]+"))
                                    {  
                                        System.out.println("Dato Invalido");
                                        System.out.println("El nombre solo puede tener letras y con un maximo de 90 letras");
                                        System.out.println("Ingrese el nombre del producto nuevamente:");
                                        nombre=scr.nextLine();
                                    } 
                                    while (nombre.length()>90 )
                                    { 
                                        System.out.println("Dato Invalido"); 
                                        System.out.println("El nombre solo puede tener letras como maximo de 90 letras");
                                        System.out.println("Ingrese el nombre del producto nuevamente:");
                                        nombre=scr.nextLine();
                                    }
                                    //*****************************************************************************************************        
                                    System.out.println("Ingrese el precio del producto: ");
                                    String precio=scr.nextLine();
                                    //verifacion del que el precio sea positivo
                                    while (precio.isEmpty())
                                    {
                                        System.out.println("Dato Invalido");
                                        System.out.println("El precio no puede estar en blanco");
                                        System.out.println("Ingrese el precio del producto nuevamente:");
                                        precio =scr.nextLine();
                                    }
                                    while (!precio.matches("[0-9]{1,8}(\\.[0-9]{2})")) 
                                    {
                                        System.out.println("Dato Invalido");
                                        System.out.println("El precio solo puede tener numeros positivos, sin espacios y con un maximo de 8 digitos y 2 decimales");
                                        System.out.println("Ingrese el precio del producto nuevamente:");
                                        precio=scr.nextLine();
                                    }
                                    //***************************************************************************************************** 
                                    poo_Almacen1 al= new  poo_Almacen1(codigo, nombre, precio);//le enviamos los datos que el usurio ingreso al objeto
                                    Registrar_prducto(al); //se llama el metodo y se le envia el objeto
                            break;
                            case 2:
                                System.out.println("Ingrese el codigo del producto que desea cambiar: ");
                                codigo =scr.nextLine();
                                Resultado = ProductoDublicado(codigo);
                                if (Resultado.equals("NO EXISTE"))
                                {
                                    System.out.println("PRODUCTO INVALIDO");
                                    System.out.println("Ese producto no esta registrado");
                                    break;
                                }
                                else
                                {
                                    System.out.println("El producto esta registrado se puede modificarlo ");
                                }
                                System.out.println("Ingrese el nuevo nombre del producto: ");
                                String nombreM=scr.nextLine();
                                //verificacion del nombre 
                                while (nombreM.trim().isEmpty())
                                { 
                                    System.out.println("Dato Invalido");
                                    System.out.println("El nombre no puede estar en blanco o lleno de espacios");
                                    System.out.println("Ingrese el nombre del producto nuevamente:");
                                    nombreM=scr.nextLine();
                                } 
                                while (!nombreM.matches("[a-zA-Z]+"))
                                {  
                                    System.out.println("Dato Invalido");
                                    System.out.println("El nombre solo puede tener letras y con un maximo de 90 letras");
                                    System.out.println("Ingrese el nombre del producto nuevamente:");
                                    nombreM=scr.nextLine();
                                } 
                                while (nombreM.length()>90 )
                                { 
                                    System.out.println("Dato Invalido"); 
                                    System.out.println("El nombre solo puede tener letras como maximo de 90 letras");
                                    System.out.println("Ingrese el nombre del producto nuevamente:");
                                    nombreM=scr.nextLine();
                                }
                                //*****************************************************************************************************        
                                System.out.println("Ingrese el nuevo precio del producto: ");
                                String precioM=scr.nextLine();
                                //verifacion del que el precio sea positivo
                                while (precioM.isEmpty())
                                {
                                    System.out.println("Dato Invalido");
                                    System.out.println("El precio no puede estar en blanco");
                                    System.out.println("Ingrese el precio del producto nuevamente:");
                                    precioM =scr.nextLine();
                                }
                                while (!precioM.matches("[0-9]{1,8}(\\.[0-9]{2})")) 
                                {
                                    System.out.println("Dato Invalido");
                                    System.out.println("El precio solo puede tener numeros positivos, sin espacios y con un maximo de 8 digitos y 2 decimales");
                                    System.out.println("Ingrese el precio del producto nuevamente:");
                                    precioM=scr.nextLine();
                                }
                                //***************************************************************************************************** 
                                poo_Almacen1 alM= new  poo_Almacen1(codigo, nombreM, precioM);//le enviamos los datos que el usurio ingreso al objeto
                                Modificar_prducto(alM); //se llama el metodo y se le envia el objeto
                        
                            default:
                                System.out.println("Salio del Almace 1");
                            break;
                        }


                    }while(opcion!=3);
                    
                break;
                case 2:
                    
                break;
                case 3:
                    
                break;
                case 4:
                    
                break;
                case 5:
                    
                break;
            
                default:
                    System.out.println("Salio del menu");
                break;
            }


        }while(opcion!=6);
    }
    public static String ProductoDublicado(String codigo)//el metodo resive la clase y objeto
    {
        try(Connection con= conexion.getConexion();
            CallableStatement cas =con.prepareCall("{CALL SP_ProductoDuplicado(?)}"))
        {
            //Connect obtiene la conexion a sql desde la clase conexion y el metodo. getConexion
            //CallableStatement
            //con.prepareCall= conexion a sql prepara la llamada al(procedimiento almacenado)
            cas.setString(1, codigo);//el primer ? del procedimiento es el num_producto que esta en el objeto al
            
            //los set de los objetos para colocar los datos en el pocedimiento

            var Resultado = cas.executeQuery();//ejecuta el procedimiento

            if(Resultado.next()) {
                return Resultado.getString("Resultado");
                
            } 
        } catch (SQLException e) {
            System.out.println("ERROR"+e.getMessage());
        }
        return "ERROR";
    }
    public static void Registrar_prducto(poo_Almacen1 alM)//el metodo resive la clase y objeto
    {
        try(Connection con= conexion.getConexion();
            CallableStatement cas =con.prepareCall("{CALL SP_GradarAlmacen01(?,?,?,?)}"))
        {
            cas.setInt(1, 1);
            //Connect obtiene la conexion a sql desde la clase conexion y el metodo. getConexion
            //CallableStatement
            //con.prepareCall= conexion a sql prepara la llamada al(procedimiento almacenado)
            cas.setString(2, alM.get_num_producto());//el primer ? del procedimiento es el num_producto que esta en el objeto al
            cas.setString(3, alM.get_nombre());//el segundo ? del procedimiento es el nombre que esta en el objeto al
            cas.setString(4, alM.get_precio());//el tercer ? del procedimiento es el nombre que esta en el objeto al
            //los set de los objetos para colocar los datos en el pocedimiento

            cas.execute();//ejecuta el procedimiento
            System.out.println("EXITOSO");
            System.out.println("Registro Exitoso");

        } catch (SQLException e) {
            System.out.println("ERROR");
            System.out.println("Error o se pudo registrar "+e.getMessage());
        } 
    }
    public static void Modificar_prducto(poo_Almacen1 al)//el metodo resive la clase y objeto
    {
        try(Connection con= conexion.getConexion();
            CallableStatement cas =con.prepareCall("{CALL SP_GradarAlmacen01(?,?,?,?)}"))
        {
            cas.setInt(1, 2);
            //Connect obtiene la conexion a sql desde la clase conexion y el metodo. getConexion
            //CallableStatement
            //con.prepareCall= conexion a sql prepara la llamada al(procedimiento almacenado)
            cas.setString(2, al.get_num_producto());//el primer ? del procedimiento es el num_producto que esta en el objeto al
            cas.setString(3, al.get_nombre());//el segundo ? del procedimiento es el nombre que esta en el objeto al
            cas.setString(4, al.get_precio());//el tercer ? del procedimiento es el nombre que esta en el objeto al
            //los set de los objetos para colocar los datos en el pocedimiento

            cas.execute();//ejecuta el procedimiento
            System.out.println("EXITOSO");
            System.out.println("Modificacion Exitosa");

        } catch (SQLException e) {
            System.out.println("ERROR");
            System.out.println("Error no se pudo Modificar "+e.getMessage());
        } 
    }
}
