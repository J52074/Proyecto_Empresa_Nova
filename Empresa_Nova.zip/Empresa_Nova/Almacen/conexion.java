package Almacen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexion {
    public static Connection getConexion() {
        String conexion ="jdbc:sqlserver://DESKTOP-MR1AO7G\\JULIOCR:62058;"
                        + "databaseName=Empresa_Nova;"
                        + "user=Empresa_Nova;"
                        + "password=01_Almacen;"
                        + "encrypt=true;"
                        +"trustServerCertificate=true";
        //loginTimeout=30;es para da un limite de tiempo para que se conecte
        try {
            
            Connection con = DriverManager.getConnection(conexion);
            System.out.println("CONEXION COMPLETA");
            return con; 
             
            
        } catch (SQLException ex) {
                System.out.println("ERROR DE CONEXION");
                System.out.println(ex.getMessage());
                return null;
        }
    }
}
